<?php
declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Metoda niedozwolona. Użyj POST.', 405);
}

$data = read_json();

$login           = trim((string) ($data['login']           ?? ''));
$password        = (string)       ($data['password']        ?? '');
$confirmPassword = (string)       ($data['confirmPassword'] ?? '');

if ($login === '' || $password === '' || $confirmPassword === '') {
    json_error('Wypełnij wszystkie pola: login, password, confirmPassword.');
}

if (mb_strlen($login) < 3) {
    json_error('Login musi mieć co najmniej 3 znaki.');
}

if (mb_strlen($password) < 6) {
    json_error('Hasło musi mieć co najmniej 6 znaków.');
}

if ($password !== $confirmPassword) {
    json_error('Hasła nie są takie same.');
}

$conn = db();


try {
    $conn->query("ALTER TABLE users MODIFY password VARCHAR(255) NOT NULL");
} catch (Throwable) {}

$stmt = $conn->prepare('SELECT id FROM users WHERE login = ?');
$stmt->bind_param('s', $login);
$stmt->execute();
$exists = $stmt->get_result()->fetch_assoc();
$stmt->close();

if ($exists) {
    json_error('Taki login już istnieje.', 409);
}

$hash = password_hash($password, PASSWORD_DEFAULT);
$stmt = $conn->prepare('INSERT INTO users (login, password) VALUES (?, ?)');
$stmt->bind_param('ss', $login, $hash);
$stmt->execute();
$userId = $stmt->insert_id;
$stmt->close();

json_response([
    'success' => true,
    'message' => 'Konto zostało utworzone pomyślnie.',
    'user' => [
        'id'    => $userId,
        'login' => $login,
    ],
], 201);
