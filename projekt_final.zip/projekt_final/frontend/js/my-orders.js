import { apiGet } from './api.js';
import { esc, money, getAuthUser, initCommonUi, loadCategories, setMessage } from './common.js';

const ordersBox  = document.querySelector('#orders-list');
const messageBox = document.querySelector('#page-message');
const typeSelect = document.querySelector('#type-filter');

function renderOrders(orders) {
    if (!orders.length) {
        ordersBox.innerHTML = '<div class="empty-state"><h2>Brak zamówień</h2></div>';
        return;
    }

    ordersBox.innerHTML = orders.map(o => `
        <div class="order-card">
            <h3>Zamówienie #${Number(o.id)} — ${esc(o.created_at)}</h3>
            <p>
                ${esc(o.first_name)} ${esc(o.last_name)},
                ${esc(o.address)}, ${esc(o.postal_code)} ${esc(o.city)}
            </p>
            <p><strong>Łącznie: $${money(o.total)}</strong></p>
            <table class="order-items-table">
                <thead>
                    <tr><th>Produkt</th><th>Cena</th><th>Ilość</th><th>Suma</th></tr>
                </thead>
                <tbody>
                    ${(o.items || []).map(i => `
                        <tr>
                            <td>${esc(i.product_name)}</td>
                            <td>$${money(i.price)}</td>
                            <td>${Number(i.quantity)}</td>
                            <td>$${money(Number(i.price) * Number(i.quantity))}</td>
                        </tr>`).join('')}
                </tbody>
            </table>
        </div>`).join('');
}

async function init() {
    initCommonUi();

    const user = getAuthUser();
    if (!user) {
        window.location.href = 'login.php';
        return;
    }

    await loadCategories([typeSelect]);

    try {
        const data = await apiGet('/my-orders.php');
        renderOrders(data.orders || []);
    } catch (err) {
        setMessage(messageBox, err.message, 'error');
    }
}

init();
