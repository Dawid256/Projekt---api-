<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logowanie — Jaguar</title>
    <link rel="shortcut icon" href="img/logo-white.png" type="image/x-icon">
    <link rel="stylesheet" href="base.css">
    <link rel="stylesheet" href="pages.css">
</head>
<body>
    <header>
        <img src="img/logo-black.png" alt="Jaguar logo">
        <h1>Jaguar</h1>
    </header>

    <main>
        <div class="login-wrap">
            <div class="login-card">
                <h2>Zaloguj się</h2>
                <p>Nowy użytkownik? <a href="register.php">Utwórz konto</a></p>
                <hr>
                <div id="page-message" class="message hidden"></div>
                <form id="login-form">
                    <label for="login">Login</label>
                    <input type="text" name="login" id="login" placeholder="Twój login" required autocomplete="username">

                    <label for="password">Hasło</label>
                    <input type="password" name="password" id="password" placeholder="Twoje hasło" required autocomplete="current-password">

                    <button type="submit">Zaloguj się</button>
                </form>
            </div>
        </div>
    </main>

    <script src="js/config.js"></script>
    <script type="module" src="js/login.js"></script>
</body>
</html>
